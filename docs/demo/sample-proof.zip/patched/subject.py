def refund(amount, days, used):
    if amount < 0 or days < 0:
        raise ValueError('negative input')
    if days > 30:
        return 0
    if used:
        return 0
    return amount
