import json, unittest
from test_acceptance import AcceptanceTests
class EvidenceResult(unittest.TextTestResult):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.rows = []
    def record(self, test, status, detail=''):
        self.rows.append({'id': test._testMethodName.removeprefix('test_'), 'status': status, 'detail': detail})
    def addSuccess(self, test):
        super().addSuccess(test); self.record(test, 'passed')
    def addFailure(self, test, err):
        super().addFailure(test, err); self.record(test, 'failed', self._exc_info_to_string(err, test))
    def addError(self, test, err):
        super().addError(test, err); self.record(test, 'error', self._exc_info_to_string(err, test))
result = unittest.TextTestRunner(verbosity=2, resultclass=EvidenceResult).run(unittest.defaultTestLoader.loadTestsFromTestCase(AcceptanceTests))
print(json.dumps({'results': result.rows, 'passed': result.testsRun-len(result.failures)-len(result.errors), 'total': result.testsRun}))
raise SystemExit(0 if result.wasSuccessful() else 1)
