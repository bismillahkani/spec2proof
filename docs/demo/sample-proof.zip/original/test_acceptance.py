import unittest
from subject import refund

class AcceptanceTests(unittest.TestCase):
    def test_AC1(self):
        # Unused item before deadline gets full refund
        self.assertEqual(refund(10000, 29, False), 10000)
    def test_AC2(self):
        # Day 30 is included
        self.assertEqual(refund(10000, 30, False), 10000)
    def test_AC3(self):
        # After deadline gets no refund
        self.assertEqual(refund(10000, 31, False), 0)
    def test_AC4(self):
        # Used items get no refund
        self.assertEqual(refund(10000, 0, True), 0)
    def test_AC5(self):
        # Zero purchase amount remains zero
        self.assertEqual(refund(0, 0, False), 0)
    def test_AC6(self):
        # Negative amount is rejected
        with self.assertRaises(ValueError):
            refund(-1, 0, False)
    def test_AC7(self):
        # Negative elapsed days are rejected
        with self.assertRaises(ValueError):
            refund(10000, -1, False)
    def test_AC8(self):
        # Same-day unused item gets full refund
        self.assertEqual(refund(1, 0, False), 1)
    def test_AC9(self):
        # Used item at deadline gets no refund
        self.assertEqual(refund(10000, 30, True), 0)
    def test_AC10(self):
        # Used and late item gets no refund
        self.assertEqual(refund(10000, 31, True), 0)

if __name__ == '__main__':
    unittest.main(verbosity=2)
