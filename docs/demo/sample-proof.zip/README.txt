Spec2Proof evidence
Run: cd original && python -m unittest -v
If approved: cd patched && python -m unittest -v
Hashes establish internal consistency, not independent attestation.
